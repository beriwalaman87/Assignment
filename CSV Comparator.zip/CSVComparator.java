
import java.io.*;
import java.util.*;

public class CSVComparator {

	/*
	 * The two scanner has been defined at class level to avoid memory leaks
	 * 
	 */
	private static Scanner scannerACSV;
	private static Scanner scannerBCSV;

	public static void main(String[] args) {
		/*
		 * ExecuteCompareCSV
		 */
		compareCSVFiles(args);
	}

	public static void compareCSVFiles(String[] args) {
		String aCSVFile = "";
		String bCSVFile = "";

		try {
			/*
			 * This is a check to find number of parameters in Command Line, for future,
			 * there must be atleast two parameters
			 */
			if ((args.length) % 2 != 0)
				throw new RuntimeException("Arguments are not correct");
			/*
			 * This condition can be modified in version 2 according to need
			 */

			if (args.length != 4)
				throw new RuntimeException(
						"This program is currently working only for two files and minimum two files needed");

			/*
			 * This for loop can be modified in future to hashmaps along with CSV reference
			 * character ('a','b' in this case) Hashmap key can be reference letter and
			 * value could be file.
			 * Hashmap can be used while initilizing linkedhashset later and so is scanner
			 */

			for (int i = 0; i < (args.length) / 2; i++) {
				switch (args[i * 2]) {
				case "-a":
					aCSVFile = args[i * 2 + 1];
					break;
				case "-b":
					bCSVFile = args[i * 2 + 1];
					break;
				}
			}
			if (aCSVFile == "" || bCSVFile == "")
				throw new RuntimeException("This arguments are not correct, two files has not been initilized");
			/*
			 * Scanner interface over Buffered Reader because of more support of collections
			 * and better performance
			 */
			scannerACSV = new Scanner(new File(aCSVFile));
			scannerBCSV = new Scanner(new File(bCSVFile));
			/*
			 * Use of Linkedhashset for two purpose 1. Avoid duplicacy while inserting into
			 * set 2. to iterate in the same order as inserted
			 */
			LinkedHashSet<String> fileAHashset = new LinkedHashSet<String>();
			LinkedHashSet<String> fileBHashset = new LinkedHashSet<String>();
			/*
			 * Additional check if one of the file is empty if this is not required, then
			 * nullpointer checks might be needed further in the program
			 */
			if (!scannerACSV.hasNext() || !scannerBCSV.hasNext()) {
				throw new RuntimeException("one of them or both of them file is empty");
			}
			/*
			 * Regex has been used to see a pattern in case of replacing it if token is
			 * encapsulated in ""
			 * 
			 * further pattern can be added if needed
			 */
			while (scannerACSV.hasNext()) {
				fileAHashset.add(scannerACSV.nextLine().replaceAll("\"([^<]*)\"", "$1"));
			}
			while (scannerBCSV.hasNext()) {
				fileBHashset.add(scannerBCSV.nextLine().replaceAll("\"([^<]*)\"", "$1"));
			}
			/*
			 * Method oriented programs so that in future, is someone else wish to use it,
			 * they can directly reuse the methods
			 */
			LinkedHashSet<String> outputHashset = new LinkedHashSet<String>();
			outputHashset = compareHashsetPayload(fileAHashset, fileBHashset);
			printHashset(outputHashset);

		} 
		/*
		 * Single exception handling area, This can be finetuned to different classes and properties file when we go for full fledged tool
		 */
		catch (FileNotFoundException e) {
			System.out.println("FileNotFound Exception Occured: " + e.getMessage());
		} catch (RuntimeException e) {
			System.out.println("Runtime Exception Occured: " + e.toString());
		}
	}
	
	/*
	 * Method to compare two hashset and return a result hashset
	 * This could be converted to any numbers of parameters
	 */

	public static LinkedHashSet<String> compareHashsetPayload(LinkedHashSet<String> fileAHashset,
			LinkedHashSet<String> fileBHashset) {
		LinkedHashSet<String> outputHashset = new LinkedHashSet<String>();
		Iterator<String> iterator2 = fileBHashset.iterator();
		Iterator<String> iterator = fileAHashset.iterator();
		/*
		 * Code snippet for handling header
		 */
		for (; iterator.hasNext();) {
			for (; iterator2.hasNext();) {
				String line = iterator.next();
				if (line.equalsIgnoreCase(iterator2.next()))
					outputHashset.add("_diff," + line);
				else
					throw new RuntimeException("Header does not match");
				break;
			}
			break;
		}
		/*
		 * Code snippet for payload verification
		 */
		for (; iterator.hasNext();) {
			String line = iterator.next();

			if (fileBHashset.contains(line)) {
				outputHashset.add("ab," + line);
			} else {
				outputHashset.add("a," + line);
			}
		}
		for (; iterator2.hasNext();) {
			String line = iterator2.next();
			if (!fileAHashset.contains(line)) {
				outputHashset.add("b," + line);
			}
		}
		return outputHashset;
	}
	
	/*
	 * Methods to print line by line content of a linked hash set
	 * Input - linkedhashset object
	 */

	public static void printHashset(LinkedHashSet<String> finalHashSet) {
		for (Iterator<String> iterator = finalHashSet.iterator(); iterator.hasNext();) {
			System.out.println(iterator.next());
		}
	}
}
